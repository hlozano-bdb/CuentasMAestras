package ade_CM_POM;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;

import Utilidades.Screenshots;

public class LoginPage extends Base {
	
	By bienvenido = By.xpath("/html/body/adpe-root/adpe-login/div/div[1]/div[2]/div[2]/h1");
	By user = By.id("nombreus");
	By password = By.id("ctrausuario"); 
	By ingresarBtn = By.id("ingresar");
	By titulo1 = By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-inbox-general/div/adpe-inbox-employee/div/adpe-inbox-list-employee/div/div[1]/h2");
	
	Screenshots screen = new Screenshots();
	
	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void Login() throws Exception {
		
		if (isDisplayed(bienvenido)) {
			
			type("hlozano", user);
			type("Bogota123*", password);
			click(ingresarBtn);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			this.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//BandejaOK_POM.jpg");
			
			
			if (isDisplayed(titulo1)) {
				System.out.println("Login de usuario OK");
				System.out.println("Ingreso a ''Bandeja de solicitudes'' OK");
				//Toma de pantalla
				assertEquals("Bandeja de solicitudes", getText(titulo1) /*titulo1.getText()*/);
				screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//USUARIO_LOGUEADO_OK.png");
				
			} else {
				System.out.println("El usuario no fu� logueado.");
				screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//USUARIO_NO_LOGUEADO.jpg");
				
			}
			
		} else {
			System.out.print("Pagina web incorrecta. por favor verifique.");
		}
		
		
		
		
	}

	
	
	
	
	
	
}
