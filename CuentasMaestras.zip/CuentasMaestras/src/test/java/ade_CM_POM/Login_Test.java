package ade_CM_POM;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import Utilidades.Screenshots;

public class Login_Test {
	
	/*
	public Login_Test(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	*/

	private WebDriver driver; 
	LoginPage loginPage; 

	@Before
	public void setUp() throws Exception {
		loginPage = new LoginPage(driver);
		driver = loginPage.chromeDriverConnection();
		driver.manage().window().maximize();
		loginPage.visit("https://adecomercial.banbogota.com.co/login");
		
	}

	@After
	public void tearDown() throws Exception {
		
		driver.quit();
		driver.close();
	}

	@Test
	public void test() throws Exception {
		loginPage.Login();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Screenshots screen = new Screenshots();
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//UTILIDAD_SCREEN_TEST.png");
		
	}

}
