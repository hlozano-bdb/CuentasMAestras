package Utilidades;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginBaseAprobador {
	
	protected WebDriver driver;
	Screenshots screen = new Screenshots();
	protected String url = "https://adecomercial.banbogota.com.co/login";
	String us = "cmora21";
	String pass = "Colombia456*";
	
	public void loginBase(WebDriver driver) throws Exception {

		By user = By.id("nombreus");
		By password = By.id("ctrausuario");
		By ingresar = By.id("ingresar");
		//WebElement tituloBandejaSolicitudes = driver.findElement(By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-inbox-general/div/adpe-inbox-employee/div/adpe-inbox-list-employee/div/div[1]/h2"));
		driver.findElement(user).sendKeys(us);
		driver.findElement(password).sendKeys(pass);
		driver.findElement(ingresar).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		
	}
	
	
	

}
