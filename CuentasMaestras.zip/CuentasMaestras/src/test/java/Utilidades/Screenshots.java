package Utilidades;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;

public class Screenshots {

	protected WebDriver driver;
	String path;

	// METODO DE CREACI�N DE LOS SCREENSHOTS.
	public void takeSnapshot(WebDriver webdriver, String fileWithPath) throws Exception {
		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
		File ScrFile = scrShot.getScreenshotAs(OutputType.FILE);
		path = "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//" + ScrFile.getName();
		File DestFile = new File(fileWithPath);
		//Files.copy(ScrFile, DestFile);
		Files.copy(ScrFile, new File(path));
	}

}
