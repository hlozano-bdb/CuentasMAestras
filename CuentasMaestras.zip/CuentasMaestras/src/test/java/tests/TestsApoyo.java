package tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utilidades.LoginBaseRadicador;
import Utilidades.Screenshots;

public class TestsApoyo {
	
	LoginBaseRadicador loginB;
	Screenshots screen = new Screenshots();
	By cerrarSesion = By.id("close-session");
	protected WebDriver driver;
	
	By body = By.xpath("/html/body");

	@Before
	public void setUp() throws Exception {
		
		loginB = new LoginBaseRadicador();
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		// driver.manage().window().maximize();
		driver.get("https://adecomercial.banbogota.com.co/login");
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws InterruptedException {
		
		System.out.println("Abre la pagina, espera 4 segundos y hace un F5");
		Thread.sleep(4000);
		driver.navigate().refresh();
		//driver.findElement(body).sendKeys(Keys.F5);
		
	}

}
