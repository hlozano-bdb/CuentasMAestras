package tests;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import Utilidades.LoginBaseRadicador;
import Utilidades.Screenshots;

public class Old_Test_2_Radicador_1_VerifDatos {

	protected WebDriver driver;
	LoginBaseRadicador loginBaseRad;
	Screenshots screen = new Screenshots();
	By cerrarSesion = By.id("close-session");

	By reservarNumCM = By.id("reserva");// Bot�n lateral "Reservar n�mero de cuenta maestra" dentro de la sesi�n.
	By modalInicioReserva = By.id("title");// Modal "Sobre la reserva de n�mero"
	By modalInicioReservaNO = By.id("no");// Bot�n NO dentro del modal "Sobre la reserva de n�mero".
	By modalInicioReservaSI = By.id("yes");// Bot�n SI dentro del modal "Sobre la reserva de n�mero".
	By nitNumber = By.id("nitNumber");// Campo de texto nit
	// Boton Cancelar
	By btnCancelar = By.xpath(
			"/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-book-account/div/div/div[2]/div/div/button[1]");
	By tituloBanSolic = By.id("h1");// titulo Bandeja de Solicitudes
	// Boton Continuar
	By btnContinuar = By.xpath(
			"/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-book-account/div/div/div[2]/div/div/button[2]");
	// Modal "Un momento por favor, estamos procesando su solicitud."
	By modalProcesando = By
			.xpath("/html/body/div[2]/div[2]/div/mat-dialog-container/adpe-modal-global/div/div[2]/div/label");

	// Datos de la empresa
	By datosEmpresa = By.id("company_data");
	// Check "He leido y acepto que los datos de la empresa son correctos"
	By checkDatosEmpresa = By.xpath(
			"/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-verify-data/div/form/div/div/div");
	By btnVerifDatosSiguiente = By.id("next");

	@Before
	public void setUp() throws Exception {

		loginBaseRad = new LoginBaseRadicador();
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://adecomercial.banbogota.com.co/login");
		// loginBaseRad.loginBase(driver);

	}

	@After
	public void tearDown() throws Exception {
		driver.findElement(cerrarSesion).click();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
		driver.quit();
	}

	@Test
	public void radicador1() throws Exception {

		loginBaseRad.loginBase(driver);
		driver.findElement(reservarNumCM).click();
		System.out.println("Inicio de Reserva.");
		System.out.println("Clic en Bot�n lateral Reservar n�mero de cuenta maestra");
		//driver.findElement(modalInicioReserva).isDisplayed();
		//Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		driver.findElement(modalInicioReservaNO).click();
		System.out.println("Clic en Bot�n NO dentro del modal ''Sobre la reserva de n�mero''");

		Thread.sleep(6000);

		driver.findElement(reservarNumCM).click();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);

		driver.findElement(modalInicioReservaSI).click();
		System.out.println("Clic en Bot�n SI dentro del modal ''Sobre la reserva de n�mero''");
		screen.takeSnapshot(driver,
				"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//InicioDeReserva.png");

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(nitNumber).clear();
		System.out.println("Ingreso del numero NIT para iniciar el caso.");
		driver.findElement(nitNumber).sendKeys("8002162766");
		System.out.println("8002162766");
		screen.takeSnapshot(driver,
				"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//NIT.png");
		driver.findElement(btnCancelar).click();
		Thread.sleep(2000);
		System.out.println("Clic en el bot�n Cancelar");
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		if (driver.findElement(tituloBanSolic).isDisplayed()) {
			driver.findElement(reservarNumCM).click();
			driver.findElement(modalInicioReservaSI).click();
			System.out.println("Clic en Bot�n SI dentro del modal ''Sobre la reserva de n�mero''");
			System.out.println("Inicio de Reserva, SI.");
			System.out.println("Ingreso del numero NIT para iniciar el caso.");
			driver.findElement(nitNumber).sendKeys("8002162766");
			System.out.println("8002162766");
			driver.findElement(btnContinuar).click();
			screen.takeSnapshot(driver,
					"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Continuar.png");
		}
		Thread.sleep(3000);
		driver.findElement(checkDatosEmpresa).click();
		System.out.println("Clic en el Check ''He le�do y acepto que los datos de la empresa son correctos.''");
		driver.findElement(btnVerifDatosSiguiente).click();
		System.out.println("Pantalla ''Verificaci�n de datos'' Clic en Siguiente");
		screen.takeSnapshot(driver,
				"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Siguiente.png");
		Thread.sleep(4000);
	}

}
