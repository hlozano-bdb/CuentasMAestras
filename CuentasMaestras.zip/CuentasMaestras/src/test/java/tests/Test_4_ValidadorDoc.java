package tests;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utilidades.LoginBaseValidador;
import Utilidades.Screenshots;

public class Test_4_ValidadorDoc extends LoginBaseValidador {
	
	private WebDriver driver;
	LoginBaseValidador loginBaseVal;
	private Map<String, Object> vars;
	JavascriptExecutor js;
	Screenshots screen = new Screenshots();
	

	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		vars = new HashMap<String, Object>();
		driver.manage().window().maximize();
		driver.get(url);
		loginBaseVal = new LoginBaseValidador();
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Exception {
		
		loginBaseVal.loginBase(driver);
		
		
		
	}

}
