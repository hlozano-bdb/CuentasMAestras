package tests;

import static org.junit.Assert.*;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import Utilidades.LoginBaseRadicador;
import Utilidades.Screenshots;

public class Test_3_Radicador_Docs extends LoginBaseRadicador {

	private WebDriver driver;
	LoginBaseRadicador loginBaseRad;
	private Map<String, Object> vars;
	JavascriptExecutor js;
	Screenshots screen = new Screenshots();

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		vars = new HashMap<String, Object>();
		driver.manage().window().maximize();
		driver.get(url);
		loginBaseRad = new LoginBaseRadicador();
	}

	@After
	public void tearDown() throws Exception {
		driver.findElement(By.id("close-session")).click();
		Thread.sleep(2000);
		driver.quit();
	}

	@Test
	public void test() throws Exception {

		loginBaseRad.loginBase(driver);
		Thread.sleep(8000);
		System.out.println("Login ok.");

		// click sobre el caso que est� en estado "Tr�mite Documental" 
		driver.findElement(By.xpath("//td[@id='state-1']//button[text()=' Tr�mite documental ']")).click();
		System.out.println("Ingreso al caso en estado 'Tr�mite Documenta'");

		//Validaci�n del titulo "N�mero de cuenta reservada"
		Assert.assertEquals("N�mero de cuenta reservada",driver.findElement(By.xpath("//label[@class='title']")).getText());  
		Thread.sleep(2000);
		System.out.println("Validaci�n del titulo 'N�mero de cuenta reservada.'");

		//Descarga del Convenio:
		driver.findElement(By.cssSelector(".btn-download")).click();
		Thread.sleep(8000);
		System.out.println("Descarga del convenio ok");

		// click boton siguiente
		driver.findElement(By.xpath("//button[@class='btn btn-next']")).click();  
		Thread.sleep(8000);
		System.out.println("Clic bot�n siguiente");
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");

		//ADJUNTAR DOCUMENTOS: 
		//Adjuntar documento 1: VCL_FOR_023 Solicitud de vinculaci�n persona jur�dica 
		File file1 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\1 - Formulario de Vinculaci�n VCL.pdf"); 
		String path1 = file1.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[1]")).sendKeys(path1); 
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000); 
		//Adjuntar documento 2: VCL FOR 029: Para condiciones especiales de manejo 
		File file2 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\2 - VCL FOR 029 Para condiciones especiales de manejo.pdf"); 
		String path2 = file2.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[2]")).sendKeys(path2); 
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 3: Rut con fecha de expedici�n menor a 30 d�as 
		File file3 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\3 - Rut con fecha de expedicion menor a 30 dias.jpg");
		String path3 = file3.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[3]")).sendKeys(path3);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 4: C�dula ordenador de gastos y/o representante legal (Alcalde)
		File file4 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\4 - CC Rep Legal ADRIANA VERGEL.jpeg");
		String path4 = file4.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[4]")).sendKeys(path4);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 5: C�dula tesorero entidad
		File file5 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\5 - CC CLARA QUEVEDO.jpg");
		String path5 = file5.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[5]")).sendKeys(path5);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 6: Acta nombramiento y posesi�n ordenado del gasto o representante legal
		File file6 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\6 - Acta nombramiento y posesi�n ordenado del gasto o representante legal.png");
		String path6 = file6.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[6]")).sendKeys(path6);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 7: Acta nombramiento y posesi�n tesorero
		File file7 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\7 - Acta nombramiento y posesi�n tesorero.png");
		String path7 = file7.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[7]")).sendKeys(path7);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 8: Carta instrucci�n manejo de cuenta 
		File file8 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\8 - Carta instrucci�n manejo de cuenta.pdf");
		String path8 = file8.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[8]")).sendKeys(path8);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		//Adjuntar documento 9: Convenio Cuentas Maestras 
		File file9 = new File("C:\\Users\\hlozanom\\OneDrive - NTT DATA EMEAL\\Documentos\\Docs\\9 - Convenio Cuentas Maestras.pdf");
		String path9 = file9.getAbsolutePath();
		driver.findElement(By.xpath("((//div[@id='div_file'])//input)[9]")).sendKeys(path9);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		System.out.println("Documentos adjuntos ok.");

		//Visualizar uno de los documentos cargados:
		//clic en el bot�n 'Previsualizar'
		driver.findElement(By.xpath("((//div[@id='viewDoc__item_1 ']//div[text()='Previsualizar']))[1]")).click();
		Thread.sleep(3000);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(3000);
		driver.findElement(By.id("close")).click();
		System.out.println("Previsualizaci�n del documento ok.");

		//Clic en el bot�n 'Enviar Documentos': 
		driver.findElement(By.id("next")).click();
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		Thread.sleep(60000);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		System.out.println("Documentos Enviados.");

		//Validaci�n del titulo "N�mero de cuenta reservada"
		Assert.assertEquals("Documentos enviados",driver.findElement(By.id("title")).getText());  
		System.out.println("Validaci�n del titulo 'Documentos enviados.' OK");
		Thread.sleep(2000);

		//Volver a la bandeja de solicitudes: 
		driver.findElement(By.id("ok")).click();
		Thread.sleep(6000);
		screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//1.png");
		System.out.println("Volver a la Bandeja de solicitudes ok");
		System.out.println("Prueba Test 3 ok.");

	}

}

































