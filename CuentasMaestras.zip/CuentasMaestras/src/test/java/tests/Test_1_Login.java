package tests;

import static org.junit.Assert.assertEquals;

//import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.concurrent.TimeUnit;

//import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

import Utilidades.LoginBaseRadicador;
import Utilidades.Screenshots;

public class Test_1_Login extends LoginBaseRadicador{
	
	protected WebDriver driver;
	LoginBaseRadicador loginB;
	Screenshots screen = new Screenshots();
	By cerrarSesion = By.id("close-session");


	@Before
	public void setUp() throws Exception {

		loginB = new LoginBaseRadicador();
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		// driver.manage().window().maximize();
		driver.get(url);

	}
	
	
	@After
	public void tearDown() throws Exception {
		
		//driver.findElement(cerrarSesion).click(); 
		//driver.close();
		//driver.quit();
	}

	@Test
	public void Login() throws Exception {

		loginB.loginBase(driver);
		
		WebElement tituloBandejaSolicitudes = driver.findElement(By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-inbox-general/div/adpe-inbox-employee/div/adpe-inbox-list-employee/div/div[1]/h2"));
		if (tituloBandejaSolicitudes.isDisplayed()) {
			System.out.println("Login Correcto.");			
			assertEquals("Bandeja de solicitudes", tituloBandejaSolicitudes.getText());
			screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//LoginRadicBandeja_OK.png");
			System.out.println("Bandeja de solicitudes OK.");
			
		} else {
			System.out.println("Login incorrecto.");
//			this.takeSnapshot(driver,"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//LoginRadicIncorrecto.jpg");
			screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//LoginRadicIncorrecto.png");
		}

	}

	@Test
	public void SesionAbierta_btn_no() throws Exception {

		loginB.loginBase(driver);

		WebElement modalSesionAbierta = driver.findElement(By.id("title"));
		WebElement modalBtnNO = driver.findElement(By.className("button-two-modal"));

		if (modalSesionAbierta.isDisplayed()) {
			// Toma de pantalla
			System.out.println("Esta sesi�n ya se encuentra en uso. Clic NO.");
			screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//SesionAbierta_btnNO.png");
			modalBtnNO.click();
		} else {
			System.out.println("La sesi�n realiza Login Correcto ya que no se encontraba abierta."); 
		}
	}

	@Test
	public void SesionAbierta_btn_si() throws Exception {

		loginB.loginBase(driver);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement modalSesionAbierta = driver.findElement(By.id("title"));
		WebElement modalBtnSI = driver.findElement(By.id("yes"));

		if (modalSesionAbierta.isDisplayed()) {
			// Toma de pantalla
			//this.takeSnapshot(driver,"C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//SesionAbierta_btnSI.jpg");
			System.out.println("Esta sesi�n ya se encuentra en uso. Clic SI");
			screen.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//SesionAbierta_btnSI.png");
			modalBtnSI.click();
			driver.close();
			driver.quit();
			System.out.println("Cerrar Sesi�n");
			Thread.sleep(6000);
		} else {
			System.out.println("La sesi�n realiza Login Correcto ya que no se encontraba abierta.");
		}

	}
	

}
