package tests;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Utilidades.LoginBaseRadicador;
import Utilidades.RadicBase_VerifDatos;
import Utilidades.Screenshots;

public class Test_OLD_2_Radicador_2_CaracteristicasCM_OLD {
	
	WebDriver driver;
	LoginBaseRadicador loginBaseRad;
	RadicBase_VerifDatos radicBase1;
	Screenshots screen = new Screenshots();
	By cerrarSesion = By.id("close-session");
	Select select;
	JavascriptExecutor js;
	
	//Acordeon "Caracteristicas de la cuenta"
	By Acordeon = By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-account-features/div/div/div[1]/form/div[4]/div[1]");
	
	//Lista desplegable Tipo de cuenta Maestra
	By ListaTipoCM = By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-account-features/div/div/div[1]/form/div[4]/div[2]/div[2]/select[1]");
	//Select select = new Select(WebElement webelement);
	//Select se = new Select(driver.findElement(By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-account-features/div/div/div[1]/form/div[4]/div[2]/div[2]/select[1]")));
	
	//Select select = new Select(driver.findElement(By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-account-features/div/div/div[1]/form/div[4]/div[2]/div[2]/select[1]")));
	
	//JavascriptExecutor js = (JavascriptExecutor) driver;
	
	//RadioButtons Datos de la reserva:
	By radioButAhorros = By.xpath("//mat-radio-button[@value='Ahorros']");
	By radioButCorriente = By.xpath("//mat-radio-button[@value='Corriente']");
	By radioButPrincipal = By.xpath("//mat-radio-button[@value='Principal']");
	By radioButPagadora = By.xpath("//mat-radio-button[@value='Pagadora']");
	By radioButNo = By.xpath("//mat-radio-button[@value='No']");
	By radioButSi = By.xpath("//mat-radio-button[@value='Si']");
	
	//Listas desplegables y opciones Automatizadas
	By txtTipoCuentaMaestra = By.xpath("//select[@formcontrolname='featuresAccountMasterType']");
	By opcTipoCM = By.xpath("//option[@value='04']");//Opcion CM sistema Gral Regalias
	By txtTipoRecurso = By.xpath("//select[@formcontrolname='featuresResourceType']");
	By opc0401 = By.xpath("((//select[@formcontrolname='featuresResourceType'])//option)[3]");//Opci�n Fondos SGR
	By tipoEntidad = By.xpath("//select[@formcontrolname='featuresEntityType']");
	By opcTipoEntidad = By.xpath("((//select[@formcontrolname='featuresEntityType'])//option)[2]");
	
	
	//Datos Nombre cliente DEpartamento, Municipio y Oficina
	By nombreClienteRUT = By.xpath("//input[@formcontrolname='featuresRUTClientName']");
	
	By departamentoEnteTerr = By.name("departments");
	String dpto = "Bogot�, D. C.";
	By opcDpto = By.id("mat-autocomplete-0");
	
	By municipioEnteTerr = By.name("towns");
	By opcMunicipioEnteTerr = By.id("cdk-overlay-8");
	String municipio = "Bogot�, D.C.";
	By oficina = By.name("office");
	String oficinaRad = "0348 - GIRARDOT";
	By opcOficinaRad = By.id("mat-autocomplete-2");
	By fondo = By.xpath("//div[@class='features-form-container']");
	
	//Boton Continuar
	By btnContinuar = By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-account-features/div/div/div[2]/div/div/button[2]");
	
	//Modal Valida la informaci�n
	By modalValidaInfo = By.id("cdk-overlay-10");
	By btnNoModalValidaInfo = By.id("no");
	By btnSiModalValidaInfo = By.id("yes");
	
	//Modal ya tiene cuentas con esas caracteristicas
	By finalizar = By.id("ok");
	
	By body = By.xpath("/html/body");
	
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		driver.get("https://adecomercial.banbogota.com.co/login");
		loginBaseRad = new LoginBaseRadicador();
		radicBase1 = new RadicBase_VerifDatos();
	}
	
	@After
	public void tearDown() throws Exception {
		
//		driver.findElement(cerrarSesion).click();
//		Thread.sleep(3000);
//		driver.close();
//		driver.quit();
	}
	
	@Test
	public void radicador2() throws Exception{
		
		loginBaseRad.loginBase(driver);
		radicBase1.radicadorBase_VerifDatos(driver);
			
		System.out.println("Inicio Caracteristicas de la cuenta maestra a reservar.");
		Thread.sleep(600);
		driver.findElement(radioButCorriente).click();
		Thread.sleep(600);
		driver.findElement(radioButAhorros).click();
		Thread.sleep(600);
		driver.findElement(radioButPagadora).click();
		Thread.sleep(600);
		driver.findElement(radioButPrincipal).click();
		Thread.sleep(600);
		driver.findElement(radioButSi).click();
		Thread.sleep(600);
		driver.findElement(radioButNo).click();
		Thread.sleep(600);
		driver.findElement(Acordeon).click();
		System.out.println("Radiobuttons OK.");
		Thread.sleep(1000);
		
		//INICIO DE PRUEBA CON NUEVO CODIGO: 
		
		driver.findElement(By.cssSelector(".input-select:nth-child(1)")).click();
		// 17 | select | css=.input-select:nth-child(1) | label=Cuenta Maestra De Salud
		// Régimen Subsidiado
		{
			WebElement dropdown = driver.findElement(By.cssSelector(".input-select:nth-child(1)"));
			dropdown.findElement(By.xpath("//option[@value='01']")).click();
		}
		// 18 | click | css=.input-select:nth-child(3) |
		driver.findElement(By.cssSelector(".input-select:nth-child(3)")).click();
		// 19 | select | css=.input-select:nth-child(3) | label=Cuenta maestra de EPS de
		// Régimen subsidiado
		{
			WebElement dropdown = driver.findElement(By.cssSelector(".input-select:nth-child(3)"));
			dropdown.findElement(By.xpath("//option[@value='EP']")).click();
		}
		// 20 | click | css=.select-placeholder |
		driver.findElement(By.cssSelector(".select-placeholder")).click();
		// 21 | select | css=.input-select:nth-child(4) | label=Entidades territoriales
		{
			WebElement dropdown = driver.findElement(By.cssSelector(".input-select:nth-child(4)"));
			dropdown.findElement(By.xpath("//option[@value = 'Entidades territoriales']")).click();
		}
		// 22 | click | css=.input-text:nth-child(6) |
		driver.findElement(By.cssSelector(".input-text:nth-child(6)")).click();
		// 23 | type | css=.input-text:nth-child(6) | prueba IDE AUTOMATION
		driver.findElement(By.cssSelector(".input-text:nth-child(6)")).sendKeys("prueba IDE AUTOMATION");
		// 24 | click | id=mat-input-1 |
		driver.findElement(By.id("mat-input-1")).click();
		// 25 | type | id=mat-input-1 | Bogotá, D
		driver.findElement(By.id("mat-input-1")).sendKeys("Bogot�, D. C.");
		// 26 | click | css=.mat-option-text |
		driver.findElement(By.cssSelector(".mat-option-text")).click();
		// 27 | click | css=body |
		driver.findElement(By.cssSelector("body")).click();
		Thread.sleep(2000);
		// 28 | click | id=mat-input-2 |
		driver.findElement(By.id("mat-input-2")).click();
		// 29 | type | id=mat-input-2 | Bog
		driver.findElement(By.id("mat-input-2")).sendKeys("Bog");
		// 30 | click | css=.mat-option-text |
		driver.findElement(By.cssSelector(".mat-option-text")).click();
		// 31 | click | css=body |
		driver.findElement(By.cssSelector("body")).click();
		Thread.sleep(2000);
		// 32 | click | id=office |
		driver.findElement(By.id("office")).click();
		// 33 | type | id=office | gir
		driver.findElement(By.id("office")).sendKeys("gir");
		// 34 | click | css=#mat-option-242 > .mat-option-text |
		driver.findElement(By.cssSelector("#mat-option-242 > .mat-option-text")).click();
		Thread.sleep(2000);
		// 35 | click | id=panel-features-form |
		driver.findElement(By.id("panel-features-form")).click();
		// 36 | click | css=.btn-next |
		driver.findElement(By.cssSelector(".btn-next")).click();
		// 37 | click | id=yes |
		driver.findElement(By.id("yes")).click();
		// 38 | runScript | window.scrollTo(0,0) |
		js.executeScript("window.scrollTo(0,0)");
		// 39 | assertElementPresent | css=.accordion-title |
		{
			List<WebElement> elements = driver.findElements(By.cssSelector(".accordion-title"));
			assert (elements.size() > 0);
		}
		
		/*
		 * //Inicio listas desplegables Tipo de CM, Tipo Recurso y Tipo Entidad.
		 * System.out.println("Inicio listas desplegables.");
		 * driver.findElement(txtTipoCuentaMaestra).click(); Thread.sleep(600);
		 * driver.findElement(opcTipoCM).click(); screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * ); driver.findElement(txtTipoRecurso).click(); Thread.sleep(1000);
		 * driver.findElement(opc0401).click(); screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * ); Thread.sleep(1000); driver.findElement(tipoEntidad).click();
		 * Thread.sleep(1000); driver.findElement(opcTipoEntidad).click();
		 * System.out.println("Listas desplegables ok."); Thread.sleep(3000);
		 * driver.findElement(nombreClienteRUT).
		 * sendKeys("Hache Automation Corporate INC.");
		 * System.out.println("Nombre cliente RUT ok."); Thread.sleep(2000);
		 * driver.findElement(departamentoEnteTerr).click();
		 * 
		 * //departamento ente territorial System.out.
		 * println("Inicio de typeo de departamento, municipio y oficina de radicaci�n."
		 * ); for (char letra:dpto.toCharArray()) {
		 * driver.findElement(departamentoEnteTerr).sendKeys(letra+""); try {
		 * Thread.sleep(80); } catch (InterruptedException e) { e.printStackTrace(); } }
		 * driver.findElement(opcDpto).click(); driver.findElement(fondo).click();
		 * System.out.println("Departamento OK."); Thread.sleep(4000);
		 * screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * );
		 * 
		 * 
		 * 
		 * //Municipio del Ente Territorial
		 * driver.findElement(municipioEnteTerr).click(); for (char
		 * letra:municipio.toCharArray()) {
		 * driver.findElement(municipioEnteTerr).sendKeys(letra+""); try {
		 * Thread.sleep(80); } catch (Exception e) { e.printStackTrace(); } }
		 * driver.findElement(opcMunicipioEnteTerr).click();
		 * driver.findElement(fondo).click(); System.out.println("Municipio OK.");
		 * Thread.sleep(2000); screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * );
		 * 
		 * 
		 * 
		 * //OFICINA DE RADICACI�N for (char letra:oficinaRad.toCharArray()) {
		 * driver.findElement(oficina).sendKeys(letra+""); try { Thread.sleep(80); }
		 * catch (InterruptedException e) { e.printStackTrace(); } }
		 * driver.findElement(opcOficinaRad).click(); driver.findElement(fondo).click();
		 * System.out.println("Oficina de Radicaci�n OK."); Thread.sleep(2000);
		 * screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * );
		 * 
		 * // driver.findElement(btnContinuar).click(); //
		 * System.out.println("Clic #1 en Continuar."); // screen.takeSnapshot(driver,
		 * //
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * ); // // //js.executeScript("window.scrollBy(0,1000)"); // //
		 * Thread.sleep(2000); // driver.findElement(btnNoModalValidaInfo).click(); //
		 * System.out.println("Clic en el bot�n Validar Informaci�n dentro del modal.");
		 * // Thread.sleep(2000); driver.findElement(btnContinuar).click();
		 * System.out.println("Clic #2 en Continuar."); Thread.sleep(2000);
		 * driver.findElement(btnSiModalValidaInfo).click();
		 * System.out.println("Clic en el bot�n continuar proceso dentro del modal.");
		 * screen.takeSnapshot(driver,
		 * "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//Lista desplegable.png"
		 * ); Thread.sleep(4000);
		 * 
		 * // if (driver.findElement(finalizar).isVisible()) { //
		 * driver.findElement(finalizar).click(); //
		 * System.out.println("Si tiene cuentas con esas caracteristicas."); // } else {
		 * // System.out.println("No tiene cuentas con esas caracteristicas."); // }
		 * 
		 * driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		 * System.out.println("prueba OK - Caracteristicas de la cuenta");
		 * //driver.findElement(body).sendKeys(Keys.F5); //driver.navigate().refresh();
		 */		
	}

}
