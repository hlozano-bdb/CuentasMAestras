package Runner_CM;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import tests.Old_Test_2_Radicador_1_VerifDatos;
import tests.Test_OLD_2_Radicador_2_CaracteristicasCM_OLD;
import tests.Test_1_Login;
import tests.Test_2_Radicador;
import tests.Test_3_Radicador_Docs;

@RunWith(Suite.class)
@SuiteClasses({ 
	//Test_1_Login.class, 
	Test_2_Radicador.class, 
	Test_3_Radicador_Docs.class


})
//@SuiteClasses({TestRadicador_1_VerifDatos.class})
public class AllTests {
	
}
