package Runner_CM;

import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

public class BanSolicRadicador {
	
	protected WebDriver driver;
	
	//METODO DE CREACI�N DE LOS SCREENSHOTS.
	public void takeSnapshot(WebDriver webdriver, String fileWithPath) throws Exception {
		TakesScreenshot scrShot =((TakesScreenshot)webdriver);
		File ScrFile=scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(fileWithPath); 
		Files.copy(ScrFile, DestFile);
	}
	
	//LOCALIZADORES
	By Bienvenido = By.xpath("/html/body/adpe-root/adpe-login/div/div[1]/div[2]/div[2]/h1");
	By user = By.id("nombreus");
	By password = By.id("ctrausuario"); 
	By ingresar = By.id("ingresar");
	
	By titulo1 = By.xpath("/html/body/adpe-root/adpe-welcome/div/adpe-sidenav/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/adpe-inbox-general/div/adpe-inbox-employee/div/adpe-inbox-list-employee/div/div[1]/h2");
	By inboxbtn = By.id("inbox");
	By reservaCmbtn = By.id("treserva");
	

	@Before
	public void setUp() throws Exception {

		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://adecomercial.banbogota.com.co/login");

	}

	@After
	public void tearDown() throws Exception {
		//driver.close();
	}

	@Test
	public void test() throws Exception {
		
		driver.findElement(user).clear();
		driver.findElement(user).sendKeys("sapraez");
		driver.findElement(password).clear();
		driver.findElement(password).sendKeys("Colombia456*");
		driver.findElement(ingresar).click();
		//driver.findElement(titulo1).;
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		if (driver.findElement(titulo1).isDisplayed()) {
			if (driver.findElement(inboxbtn).isDisplayed()) {
				if (driver.findElement(reservaCmbtn).isDisplayed()) {
					System.out.println("Bandeja de Solicitudes Radicador OK");
				}
			}
		} else {
			this.takeSnapshot(driver, "C://Users//hlozanom//OneDrive - NTT DATA EMEAL//Documentos//Automatizacion//Screenshots//BandejaSolicRadicador_ERROR.jpg");
			System.out.println("Error en la pagina.");
		}
		
	}

}
